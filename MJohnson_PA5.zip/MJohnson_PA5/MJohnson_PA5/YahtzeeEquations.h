#ifndef YAHTZEEEQUATIONS_H
#define YAHTZEEEQUATIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define RULES 1
#define START_GAME 2
#define EXIT 3

void display_menu(void);
int get_option(void);
int is_valid(int option);
int run_menu(void);
void determine_operation(int option,int *game_over_ptr);
char combo_or_save(int *dice, int *number_of_rolls_ptr, int *combo_option_ptr);
void choose_menu();
void determine_count_of_each_die(int dice[], int size_dice, int count[], int size_count);
void score_obtained(int comb[], int comb_used[], int dice_count[], int size, int *combo_option_ptr);
int turn_reset_p1(int dice[], int count[], int *number_of_rolls_ptr, int *combo_option_ptr);
int turn_reset_p2(int dice[], int count[], int *number_of_rolls_ptr, int *combo_option_ptr, int rounds);
int get_p1_total_score(int comb[]);


#endif