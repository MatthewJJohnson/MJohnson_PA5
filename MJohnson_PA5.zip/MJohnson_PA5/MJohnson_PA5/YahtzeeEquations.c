#include "YahtzeeEquations.h"


/*************************************************************
* Function: void display_menu(void)
* Date Created:        3:6:16
* Date Last Modified:      3:6:16
* Description:     This program prints the options that the user can enter.
* Returns:				void
*************************************************************/
void display_menu(void)
{
	printf("Welcome to the game of YAHTZEE!\n Select an option by typing the corresponding number.\n");
	printf("1. YAHTZEE rules.\n");
	printf("2. Start YAHTZEE.\n");
	printf("3. Exit.\n");
}

/*************************************************************
* Function: int get_option(void)
* Date Created:        3:6:16
* Date Last Modified:      3:6:16
* Description:     This program recieves the option form the user.
* Returns:				option
*************************************************************/
int get_option(void)
{
	int option = 0;

	scanf("%d", &option);
	return option;
}

/*************************************************************
* Function: int is_valid(int option)
* Date Created:        3:6:16
* Date Last Modified:      3:6:16
* Description:     This program check that the entered option is a 1,2, or 3.
* Returns:				status
*************************************************************/
int is_valid(int option)
{
	int status = 1;

	if ((option < 1) || (option > 3))
	{
		status = 0; //invalid
	}
	return status;
}

/*************************************************************
* Function: int run_menu(void)
* Date Created:        3:6:16
* Date Last Modified:      3:6:16
* Description:     This program runs the first three created functions
					in an effort to reduce repetition.
* Returns:				option
*************************************************************/
int run_menu(void)
{
	int status = 0, option = 0;
	do
	{
		display_menu(); // display menu
		option = get_option(); // get option from user
		status = is_valid(option); // check the validity of the option
	} while (status == 0); // status != 1
	return option;
}

/*************************************************************
* Function: void determine_operation(int option, int *game_over_ptr)
* Date Created:        3:6:16
* Date Last Modified:      3:9:16
* Description:     This program runs a switch statment that either prints the rules,
					proceeds in main, or ends the running program.
* Returns:				void
*************************************************************/
void determine_operation(int option, int *game_over_ptr)
{
	system("cls");
	switch (option)
	{
	case RULES: printf("The rules of YAHTZEE are as follows.\n");
		printf("To start with, roll all the dice.\nAfter rolling you can either score the current roll (see below), or re-roll any or all of the dice.\nYou may only roll the dice a total of 3 times. After rolling 3 times you must choose a category to score.\nYou may score the dice at any point in the round, i.e.it doesn't have to be after the 3rd roll.\n");
		printf("If you score in the upper section of the table, your score is the total of the specified die face.\nBonus If the total of Upper scores is 63 or more, add a bonus of 35.\n");
		printf("For 3 of a kind you must have at least 3 of the same die faces. You score the total of all the dice.\nFor 4 of a kind you would need 4 die faces the same and again score the total.\n");
		printf("A Straight is a sequence of consecutive die faces, where a small straight is 4 consecutive faces, and a large straight 5 consecutive faces.\nSmall straights score 30 and a large straight scores 40 points.\n");
		printf("A Full House is where you have 3 of a kind and 2 of a kind. Full houses score 25 points.\n");
		printf("A Yahtzee is 5 of a kind and scores 50 points.\n");
		printf("You can roll anything and be able to put it in the Chance category. You score the total of the die faces.\n");
		printf("You can score any roll in any category at any time, even if the resulting score is zero.\n");
		printf("\n\n");
		option = run_menu();
		determine_operation(option, game_over_ptr);
		break;
	case START_GAME:
		break;
	case EXIT: printf("Sorry to see you leave the game so soon, Goodbye Player!\n");
		exit(1);
		break;
	default:
		break;
	}
}

/*************************************************************
* Function: void choose_menu()
* Date Created:        3:6:16
* Date Last Modified:      3:9:16
* Description:     This function displays the possible choices of the game yahtzee.
* Returns:				void
*************************************************************/
void choose_menu()
{
	printf("1. Ones		8. Four-Of-A-Kind\n");
	printf("2. Twos		9. Full House\n");
	printf("3. Threes	10. Small Straight\n");
	printf("4. Fours	11. Large Straight\n");
	printf("5. Fives	12. Chance\n");
	printf("6. Sixes	13. Yahtzee\n");
	printf("7. Three-Of-A-Kind\n");
}


//Dice is a pointer to an array of integers
/*************************************************************
* Function: void roll_dice(int *dice, int size, int *number_of_rolls_ptr)
* Date Created:        3:6:16
* Date Last Modified:      3:9:16
* Description:     This function rolls 6 dice randomly.
* Returns:				void
*************************************************************/
void roll_dice(int *dice, int size, int *number_of_rolls_ptr)
{
	int index = 0;
	int number_of_rolls = 0;
	printf("You have rolled the following dice. ");
	for (index = 0; index < size; ++index)
	{
		if (dice[index] == 0)

		{
			dice[index] = rand() % 6 + 1;
		}
		printf("\nDie %d:%d ", index+1, dice[index]);
	}
	number_of_rolls = *number_of_rolls_ptr;
	number_of_rolls += 1; 
	*number_of_rolls_ptr = number_of_rolls;
	printf("\nRolls this turn: %d\n", *number_of_rolls_ptr);
}

/*************************************************************
* Function: char combo_or_save(int *dice, int *number_of_rolls_ptr, int *combo_option_ptr)
* Date Created:        3:6:16
* Date Last Modified:      3:9:16
* Description:     This function prompts the user to decide if they want to
					choose an option or roll again. If they choose an option
					that is stored, if they roll again, they can save dice and
					roll up to two more times.
* Returns:				result
*************************************************************/
char combo_or_save(int *dice, int *number_of_rolls_ptr, int *combo_option_ptr)
{
	char result = '\0';
	int valid = 0, rerolldie = 0, index = 0, reroll = 0, option = 0;
	printf("Would you like to use a combination for this roll? (Y)\n");
	printf("If not, you may choose to save dice and roll again. (N)\n");
	do {
		scanf(" %c", &result);
		if (result == 'Y')
		{
			valid = 1;
			printf("Choose an option by typing a number.\n");
			choose_menu();
			scanf(" %d", &option);
			*combo_option_ptr = option;
			break;
		}
		else if (result == 'N')
		{
			do
			{
				valid = 1;
				printf("Choose a dice to re-roll.");
				scanf("%d", &rerolldie);
				index = rerolldie;
				dice[index - 1] = 0;
				printf("Would you like to re-roll another dice? Enter 0, If not enter a 1.");
				scanf("%d", &reroll);
			} while (reroll == 0);
			system("cls");
			roll_dice(dice, 5, number_of_rolls_ptr);
		}
		printf("Would you like to use a combination for this roll? (Y)\n");
		printf("If not, you may choose to save dice and roll again. (N)\n");
		do {
			scanf(" %c", &result);
			if (result == 'Y')
			{
				valid = 1;
				printf("Choose an option by typing a number.\n");
				choose_menu();
				scanf(" %d", &option);
				*combo_option_ptr = option;
				break;
			}
			else if (result == 'N')
			{
				do
				{
					valid = 1;
					printf("Choose a dice to re-roll.");
					scanf(" %d", &rerolldie);
					index = rerolldie;
					dice[index - 1] = 0;
					printf("Would you like to re-roll another dice? Enter 0, If not enter a 1.");
					scanf(" %d", &reroll);
				} while (reroll == 0);
				system("cls");
				roll_dice(dice, 5, number_of_rolls_ptr);

				valid = 1;
				printf("Choose an option by typing a number.\n");
				choose_menu();
				scanf(" %d", &option);
				*combo_option_ptr = option;
			}
		} while (valid == 0);
	} while (valid == 0);
	return result;
}

/*************************************************************
* Function: void determine_count_of_each_die(int dice[], int size_dice, int count[], int size_count)
* Date Created:        3:6:16
* Date Last Modified:      3:9:16
* Description:     This function determines how many of each die
					were rolled and displays that result.
* Returns:				void
*************************************************************/
void determine_count_of_each_die(int dice[], int size_dice, int count[], int size_count)
{
	int index = 0;

	for (index = 0; index < size_dice; index++)
	{
		count[dice[index]] += 1; // Can also use count[*(dice + index)] += 1;
	}
	for (index = 1; index < size_count; index++)
	{
		printf("Die Total %d:%d\n", index, count[index]);
	}
}

/*************************************************************
* Function: void score_obtained(int comb[], int comb_used[], int dice_count[], int size, int *combo_option_ptr)
* Date Created:        3:6:16
* Date Last Modified:      3:9:16
* Description:     This function compares the dice that were rolled and
					executes the point total to the option that they chose.
					if they dont have what they chose, they get 0.
					this function prevents them from choosing the same option
					twice.
were rolled and displays that result.
* Returns:				void
*************************************************************/
void score_obtained(int comb[], int comb_used[], int dice_count[], int size, int *combo_option_ptr)
{
	int option = 0, accepted = 0, result = 0;
	do
	{
		if ((comb_used[*combo_option_ptr] != 1) && ((*combo_option_ptr >= 1) && (*combo_option_ptr <= 6))) //Can use sum of one through sixes
		{
			accepted = 1;
			comb[*combo_option_ptr] = dice_count[*combo_option_ptr] * *combo_option_ptr;

			comb_used[*combo_option_ptr] = 1;
		}
		else if ((comb_used[*combo_option_ptr] == 1) && ((*combo_option_ptr >= 1) && (*combo_option_ptr <= 6)))
		{
			accepted = 0;
			printf("You have already used this combo. Re-Enter a choice.\n");
			choose_menu();
			scanf(" %d", &option);
			*combo_option_ptr = option;
		}
		//doing 7
		if ((comb_used[*combo_option_ptr] != 1) && (*combo_option_ptr == 7))
		{
			if (((dice_count[1] >= 3) || ((dice_count[2] >= 3) || ((dice_count[3] >= 3) || ((dice_count[4] >= 3) || ((dice_count[5] >= 3) || (dice_count[6] >= 3)))))))
			{
				accepted = 1;
				comb[7] = dice_count[1] * 1 + dice_count[2] * 2 + dice_count[3] * 3 + dice_count[4] * 4 + dice_count[5] * 5 + dice_count[6] * 6;
				comb_used[7] = 1;
			}
			else
			{
				accepted = 1;
				comb[7] = 0;
			}
		}
		else if ((comb_used[*combo_option_ptr] == 1) && (*combo_option_ptr == 7))
		{
			accepted = 0;
			printf("You have already used this combo. Re-Enter a choice.\n");
			choose_menu();
			scanf(" %d", &option);
			*combo_option_ptr = option;
		}
		//doing 8
		if ((comb_used[*combo_option_ptr] != 1) && (*combo_option_ptr == 8))
		{
			if (((dice_count[1] >= 4) || ((dice_count[2] >= 4) || ((dice_count[3] >= 4) || ((dice_count[4] >= 4) || ((dice_count[5] >= 4) || (dice_count[6] >= 4)))))))
			{
				accepted = 1;
				comb[8] = dice_count[1] + dice_count[2] * 2 + dice_count[3] * 3 + dice_count[4] * 4 + dice_count[5] * 5 + dice_count[6] * 6;
				comb_used[8] = 1;
			}
			else
			{
				accepted = 1;
				comb[8] = 0;
			}
		}
		else if ((comb_used[*combo_option_ptr] == 1) && (*combo_option_ptr == 8))
		{
			accepted = 0;
			printf("You have already used this combo. Re-Enter a choice.\n");
			choose_menu();
			scanf(" %d", &option);
			*combo_option_ptr = option;
		}
		// doing 9
		if ((comb_used[*combo_option_ptr] != 1) && (*combo_option_ptr == 9))
		{
			if (((dice_count[1] == 3) || ((dice_count[2] == 3) || ((dice_count[3] == 3) || ((dice_count[4] == 3) || ((dice_count[5] == 3) || (dice_count[6] == 3)))))) && ((dice_count[1] == 2) || ((dice_count[2] == 2) || ((dice_count[3] == 2) || ((dice_count[4] == 2) || ((dice_count[5] == 2) || (dice_count[6] == 2)))))))
			{
				accepted = 1;
				comb[9] = 25;
				comb_used[9] = 1;
			}
			else
			{
				accepted = 1;
				comb[9] = 0;
			}
		}
		else if ((comb_used[*combo_option_ptr] == 1) && (*combo_option_ptr == 9))
		{
			accepted = 0;
			printf("You have already used this combo. Re-Enter a choice.\n");
			choose_menu();
			scanf(" %d", &option);
			*combo_option_ptr = option;
		}

		// doing 10
		if ((comb_used[*combo_option_ptr] != 1) && (*combo_option_ptr == 10))
		{
			if ((((dice_count[1] >= 1) && ((dice_count[2] >= 1) && ((dice_count[3] >= 1) && ((dice_count[4] >= 1))))) || ((dice_count[2] >= 1) && ((dice_count[3] >= 1) && ((dice_count[4] >= 1) && ((dice_count[5] >= 1)))))) || ((dice_count[3] >= 1) && ((dice_count[4] >= 1) && ((dice_count[5] >= 1) && ((dice_count[6] >= 1))))))
			{
				accepted = 1;
				comb[10] = 30;
				comb_used[10] = 1;
			}
			else
			{
				accepted = 1;
				comb[10] = 0;
			}
		}
		else if ((comb_used[*combo_option_ptr] == 1) && (*combo_option_ptr == 10))
		{
			accepted = 0;
			printf("You have already used this combo. Re-Enter a choice.\n");
			choose_menu();
			scanf(" %d", &option);
			*combo_option_ptr = option;
		}

		// doing 11
		if ((comb_used[*combo_option_ptr] != 1) && (*combo_option_ptr == 11))
		{
			if (((dice_count[1] == 1) && ((dice_count[2] == 1) && ((dice_count[3] == 1) && ((dice_count[4] == 1) && ((dice_count[5] == 1)))))) || ((dice_count[2] == 1) && ((dice_count[3] == 1) && ((dice_count[4] == 1) && ((dice_count[5] == 1) && ((dice_count[6] == 1)))))))
			{
				accepted = 1;
				comb[11] = 40;
				comb_used[11] = 1;
			}
			else
			{
				accepted = 1;
				comb[11] = 0;
			}
		}
		else if ((comb_used[*combo_option_ptr] == 1) && (*combo_option_ptr == 11))
		{
			accepted = 0;
			printf("You have already used this combo. Re-Enter a choice.\n");
			choose_menu();
			scanf(" %d", &option);
			*combo_option_ptr = option;
		}

		// doing 12
		if ((comb_used[*combo_option_ptr] != 1) && (*combo_option_ptr == 12))
		{

			accepted = 1;
			comb[12] = dice_count[1] * 1 + dice_count[2] * 2 + dice_count[3] * 3 + dice_count[4] * 4 + dice_count[5] * 5 + dice_count[6] * 6;
			comb_used[12] = 1;
		}
		else if ((comb_used[*combo_option_ptr] == 1) && (*combo_option_ptr == 12))
		{
			accepted = 0;
			printf("You have already used this combo. Re-Enter a choice.\n");
			choose_menu();
			scanf(" %d", &option);
			*combo_option_ptr = option;
		}

		// doing 13
		if ((comb_used[*combo_option_ptr] != 1) && (*combo_option_ptr == 13))
		{
			if ((dice_count[1] == 5) || ((dice_count[2] == 5) || ((dice_count[3] == 5) || ((dice_count[4] == 5) || ((dice_count[5] == 5) || ((dice_count[6] == 5)))))))
			{
				accepted = 1;
				comb[13] = 50;
				comb_used[13] = 1;
			}
			else
			{
				accepted = 1;
				comb[13] = 0;
			}
		}
		else if ((comb_used[*combo_option_ptr] == 1) && (*combo_option_ptr == 13))
		{
			accepted = 0;
			printf("You have already used this combo. Re-Enter a choice.\n");
			choose_menu();
			scanf(" %d", &option);
			*combo_option_ptr = option;
		}
	}while (accepted == 0);
}

/*************************************************************
* Function: int turn_reset_p2(int dice[], int count_dice_values[], int *number_of_rolls_ptr, int *combo_option_ptr, int rounds)
* Date Created:        3:6:16
* Date Last Modified:      3:10:16
* Description:     This function resets the aray passed in as count[]
					and the array pased in as count_dice_values[] for player 2 to arrays of '\0'.
					This function also resets the number_of_rolls_ptr and the 
					combo_option_ptr to 0. This function increments the number of rounds by 1.
were rolled and displays that result.
* Returns:				rounds_complete
*************************************************************/
int turn_reset_p2(int dice[], int count_dice_values[], int *number_of_rolls_ptr, int *combo_option_ptr, int rounds)
{
	int rounds_complete = 0;

	printf("Player Two is starting their turn. Hit any key to begin.\n");
	system("pause");
	system("cls");
	dice[0] = 0;
	dice[1] = 0;
	dice[2] = 0;
	dice[3] = 0;
	dice[4] = 0;
	count_dice_values[1] = 0;
	count_dice_values[2] = 0;
	count_dice_values[3] = 0;
	count_dice_values[4] = 0;
	count_dice_values[5] = 0;
	count_dice_values[6] = 0;
	*number_of_rolls_ptr = 0;
	*combo_option_ptr = 0;
	rounds_complete = rounds + 1;
	return rounds_complete;
}

/*************************************************************
* Function: int turn_reset_p2(int dice[], int count_dice_values[], int *number_of_rolls_ptr, int *combo_option_ptr)
* Date Created:        3:6:16
* Date Last Modified:      3:10:16
* Description:     This function resets the aray passed in as count[]
					and the array pased in as count_dice_values[] for player 1 to arrays of '\0'.
					This function also resets the number_of_rolls_ptr and the
					combo_option_ptr to 0.
* Returns:				rounds_complete
*************************************************************/
int turn_reset_p1(int dice[], int count_dice_values[], int *number_of_rolls_ptr, int *combo_option_ptr)
{
	int rounds_complete = 0;

	printf("Player One is starting their turn. Hit any key to begin.\n");
	system("pause");
	system("cls");
	dice[0] = 0;
	dice[1] = 0;
	dice[2] = 0;
	dice[3] = 0;
	dice[4] = 0;
	count_dice_values[1] = 0;
	count_dice_values[2] = 0;
	count_dice_values[3] = 0;
	count_dice_values[4] = 0;
	count_dice_values[5] = 0;
	count_dice_values[6] = 0;
	*number_of_rolls_ptr = 0;
	*combo_option_ptr = 0;
	return rounds_complete;
}

/*************************************************************
* Function: int get_p1_total_score(int comb[])
* Date Created:        3:6:16
* Date Last Modified:      3:10:16
* Description:     This function adds the total number of uppers and lowrs for player 1 and player 2.
					If the upper section is 63 or more, 35 is aded to the total.
* Returns:				total_total
*************************************************************/
int get_p1_total_score(int comb[])
{
	int total_upper = 0;
	int total_lower = 0;
	int total_total = 0;

	total_upper = comb[1] + comb[2] + comb[3] + comb[4] + comb[5] + comb[6];
	if (total_upper >= 63)
	{
		total_upper += 35;
	}
	total_lower = comb[7] + comb[8] + comb[9] + comb[10] + comb[11] + comb[12] + comb[13];
	total_total = total_lower + total_upper;
	return total_total;
}

/*************************************************************
* Function: void determine_winner(p1_total, p2_total)
* Date Created:        3:6:16
* Date Last Modified:      3:10:16
* Description:     This function determines if player one wins, player two wins, 
					or there is a tie and prints the result.
					
* Returns:				void
*************************************************************/
void determine_winner(p1_total, p2_total)
{
	if (p1_total > p2_total)
	{
		printf("Player One Final Score: %d\n", p1_total);
		printf("Player Two Final Score: %d\n", p2_total);
		printf("Player One Wins!\n");
		system("pause");
		system("cls");

	}
	else if (p1_total < p2_total)
	{
		printf("Player One Final Score: %d\n", p1_total);
		printf("Player Two Final Score: %d\n", p2_total);
		printf("Player Two Wins!\n");
		system("pause");
		system("cls");
	}
	else if (p1_total == p2_total)
	{
		printf("Player One Final Score: %d\n", p1_total);
		printf("Player Two Final Score: %d\n", p2_total);
		printf("Nobody Wins!\n");
		system("pause");
		system("cls");
	}
}