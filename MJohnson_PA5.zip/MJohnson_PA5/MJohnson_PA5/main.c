#include "YahtzeeEquations.h"

int main(void)
{
	int option = 0, size_dice = 6, size_count = 0, game_over = 0, number_of_rolls = 0, combination_choice = 0, result = 0, rounds_1 = 0, rounds_2 = 0, combo_option = 0, player1_total = 0, player2_total = 0;
	int *number_of_rolls_ptr = &number_of_rolls;
	int *combo_option_ptr = &combo_option;
	int *game_over_ptr = &game_over;
	int dice[5] = { 0 };
	int count_dice_values[7] = { 0 };
	int comb_score_p1[14] = { 0 };
	int comb_score_p2[14] = { 0 };
	int comb_used_p1[14] = { 0 };
	int comb_used_p2[14] = { 0 };
	srand((unsigned int)time(NULL));

	do
	{
		option = run_menu();
		determine_operation(option, game_over_ptr);

		do
		{
			rounds_1 = turn_reset_p1(dice, count_dice_values, number_of_rolls_ptr, combo_option_ptr); //Perform value clearing
			roll_dice(dice, 5, number_of_rolls_ptr); //Rolls and displays dice
			result = combo_or_save(dice, number_of_rolls_ptr, combo_option_ptr); //Re-rolls up to 3 rolls or forces a combination choice
			determine_count_of_each_die(dice, 5, count_dice_values, 7); // determines how many of each die player 1 has
			score_obtained(comb_score_p1, comb_used_p1, count_dice_values, 7, combo_option_ptr); //save a round score for p1 in the score array, DOESNT SUCCESSFULLY CHECK FOR USED
			printf("Player One, You have gained a score of %d\n", comb_score_p1[*combo_option_ptr]); // display player 1's point gain for that round

			rounds_2 = turn_reset_p2(dice, count_dice_values, number_of_rolls_ptr, combo_option_ptr, rounds_2); //Perform value clearing

			roll_dice(dice, 5, number_of_rolls_ptr); //Rolls and displays dice
			result = combo_or_save(dice, number_of_rolls_ptr, combo_option_ptr); //Re-rolls up to 3 rolls or forces a combination choice
			determine_count_of_each_die(dice, 5, count_dice_values, 7); // determines how many of each die player 2 has
			score_obtained(comb_score_p2, comb_used_p2, count_dice_values, 7, combo_option_ptr); //save a round score for p2 in the score array, DOESNT SUCCESSFULLY CHECK FOR USED
			printf("Player Two, You have gained a score of %d\n", comb_score_p2[*combo_option_ptr]); // display player 2's point gain for that round
			printf("Rounds complete: %d\n", rounds_2);		//Indicate and add 1 to a successful round completion
		} while (rounds_2 < 13);
		
		system("pause");
		system("cls");
		player1_total = get_p1_total_score(comb_score_p1);
		player2_total = get_p1_total_score(comb_score_p2);
		determine_winner(player1_total, player2_total);

	} while (*game_over_ptr == 0);
	

	
}